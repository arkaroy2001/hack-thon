class ApiError(Exception):
    pass


class UsageError(Exception):
    pass
